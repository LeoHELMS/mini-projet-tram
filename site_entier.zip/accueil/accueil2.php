<?php include("../connexion.html"); ?>

<br/><br/>
<img src="/accueil/tram.png" style="height:200px; width: 300px; margin-left: 25px;">
<br/><br/>

<a href="/electronic/electronic.php">Lien de présentation de l'électronique dans les transports en communs
</a><br/>
<br/><br/>

<?php include("../fin.html"); ?>

</body>
</html>