<!DOCTYPE html>
<html>
<head>

<link rel="icon" href="/CTS.png"/>
<title>CTS - Accueil</title>

<script type="text/javascript">

</script>

<link rel="stylesheet" type="text/css" href="/css/accueil.css">

</head>
<body>

<?php include("accueil2.php"); ?>