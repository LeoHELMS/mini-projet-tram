<?php
$_user_login="Leo";
$_user_pass="9b3a00aa32b02a3b9c3fafd3a4dbe814"; //HELMS

$_admin_login="admin";
$_admin_pass="1b208523f367f14a5129e7727886eda1"; //motdepasseextremementlong
?>